package com.damianosiak.semestr2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Semestr2Application {

    public static void main(String[] args) {
        SpringApplication.run(Semestr2Application.class, args);
    }

}
